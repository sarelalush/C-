#include <iostream>
#include <string>
#include "Counter.h"
#include <fstream>
#include "Parser.h"
using namespace std;
int main() {
    Parser p;
    p.menu();

//    Counter<int> sc("String","Shai");
//    sc.add_from_stream(cin);
//    sc.print_most_common(cout);

    return 0;
}
